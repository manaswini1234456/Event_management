from django.contrib import admin
from .models import UserInfo1, Event, Admin, Booking, Hall, Notification

admin.site.register(UserInfo1)
admin.site.register(Event)
admin.site.register(Admin)
admin.site.register(Booking)
admin.site.register(Hall)
admin.site.register(Notification)
