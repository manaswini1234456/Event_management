# Event-Management
> ## Project explaination or Abstract
> ---
>

> ## UML Diagram
>  ---
> 
